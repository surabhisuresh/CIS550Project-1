var express = require('express');
var router = express.Router();
var mongoose = require('mongoose');
mongoose.createConnection('ec2-184-72-93-234.compute-1.amazonaws.com:27017/ingredient');
var Schema = mongoose.Schema;

var subDataSchema = new Schema({
  Ingredient: {type: String, required: true},
  Amount: String,
  Substitution: String
}, {collection: 'substitutes'});

var subData = mongoose.model('subData', subDataSchema);

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index');
});

router.get('/get-data', function(req, res, next) {
  subData.find()
      .then(function(doc) {
        res.render('index', {items: doc});
      });
});

router.post('/insert', function(req, res, next) {
  var item = {
    Ingredient: req.body.Ingredient,
    Amount: req.body.Amount,
    Substitution: req.body.Substitution
  };

  var data = new subData(item);
  data.save();

  res.redirect('/');
});

router.post('/update', function(req, res, next) {
  var id = req.body.id;

  subData.findById(id, function(err, doc) {
    if (err) {
      console.error('error, no entry found');
    }
    doc.Ingredient = req.body.Ingredient;
    doc.Amount = req.body.Amount;
    doc.Substitution = req.body.Substitution;
    doc.save();
  })
  res.redirect('/');
});

router.post('/delete', function(req, res, next) {
  var id = req.body.id;
  subData.findByIdAndRemove(id).exec();
  res.redirect('/');
});

module.exports = router;
