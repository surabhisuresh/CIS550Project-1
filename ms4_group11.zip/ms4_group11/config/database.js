module.exports = {

	// the database url to connect
	url : 'ec2-184-72-93-234.compute-1.amazonaws.com:27017/ingredient'
}
